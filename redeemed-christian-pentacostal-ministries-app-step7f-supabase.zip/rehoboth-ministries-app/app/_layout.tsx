import { Stack } from 'expo-router';
import { useEffect } from 'react';
import { registerDeviceWithServer, scheduleWeeklyReminders } from '../lib/notifications';
export default function RootLayout(){useEffect(()=>{registerDeviceWithServer().catch(console.warn);scheduleWeeklyReminders().catch(console.warn)},[]);return <Stack screenOptions={{headerShown:false}}><Stack.Screen name="index"/><Stack.Screen name="auth"/><Stack.Screen name="profile"/><Stack.Screen name="prayer"/><Stack.Screen name="events"/><Stack.Screen name="live"/><Stack.Screen name="contact"/><Stack.Screen name="admin"/></Stack>}
