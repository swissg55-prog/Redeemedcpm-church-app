# Redeemed Christian Pentacostal Ministries App

Expo/React Native app for iPhone and Android.

## Step 5: Church Management Dashboard

The admin dashboard now supports:
- Registered member list
- Prayer-request review and status management
- Create/show/hide/delete church events
- Save and send push-notification announcements
- Manage church phone, WhatsApp, email, address and livestream URL
- Secure admin-only access based on the `profiles.role = 'admin'` field

## Supabase setup
1. Create a Supabase project.
2. Run `supabase-schema.sql` in SQL Editor.
3. Create an administrator account in Supabase Auth.
4. Promote that account to admin with:
   `update public.profiles set role='admin' where id='<AUTH_USER_UUID>';`
5. Configure `.env` from `.env.example`.
6. Deploy `supabase/functions/send-notification` and set `SUPABASE_SERVICE_ROLE_KEY` as a server secret.
7. Configure Expo/EAS push credentials before production builds.

Never place the Supabase service-role key in the mobile app.
