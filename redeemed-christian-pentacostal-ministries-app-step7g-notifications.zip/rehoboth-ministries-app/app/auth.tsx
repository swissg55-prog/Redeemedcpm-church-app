import { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { supabase, supabaseConfigured } from '../lib/supabase';

export default function Auth() {
  const [mode, setMode] = useState<'signin'|'signup'>('signin');
  const [name, setName] = useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [busy,setBusy]=useState(false);
  useEffect(()=>{supabase.auth.getSession().then(({data})=>{if(data.session) router.replace('/profile')})},[]);
  async function submit(){
    if(!supabaseConfigured) return Alert.alert('Setup required','Connect the app to Supabase first.');
    if(!email||password.length<6||(mode==='signup'&&!name.trim())) return Alert.alert('Check details','Enter all required details. Password must be at least 6 characters.');
    setBusy(true);
    if(mode==='signin'){
      const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});
      if(error) Alert.alert('Sign in failed',error.message); else router.replace('/profile');
    } else {
      const {data,error}=await supabase.auth.signUp({email:email.trim(),password,options:{data:{full_name:name.trim()}}});
      if(error) Alert.alert('Registration failed',error.message);
      else if(data.session) router.replace('/profile'); else Alert.alert('Check your email','Your account was created. Check your email if confirmation is enabled, then sign in.');
    }
    setBusy(false);
  }
  return <ScrollView contentContainerStyle={s.c} keyboardShouldPersistTaps="handled"><Text style={s.h}>Member {mode==='signin'?'Sign In':'Registration'}</Text><Text style={s.p}>Stay connected with Redeemed Christian Pentacostal Ministries.</Text>
    {mode==='signup'&&<TextInput style={s.input} placeholder="Full name" value={name} onChangeText={setName}/>}<TextInput style={s.input} placeholder="Email address" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail}/><TextInput style={s.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword}/>
    <Pressable style={[s.btn,busy&&{opacity:.5}]} disabled={busy} onPress={submit}><Text style={s.bt}>{busy?'Please wait…':mode==='signin'?'Sign In':'Create Account'}</Text></Pressable>
    <Pressable onPress={()=>setMode(mode==='signin'?'signup':'signin')} style={s.link}><Text style={s.linkText}>{mode==='signin'?'New member? Create an account':'Already have an account? Sign in'}</Text></Pressable>
  </ScrollView>
}
const s=StyleSheet.create({c:{flexGrow:1,padding:24,backgroundColor:'#F7F4FA',justifyContent:'center'},h:{fontSize:31,fontWeight:'900',color:'#24132F'},p:{color:'#6E6175',marginVertical:12,lineHeight:22},input:{backgroundColor:'#fff',borderRadius:14,borderWidth:1,borderColor:'#DED3E4',padding:15,marginTop:10},btn:{backgroundColor:'#4B197D',padding:17,borderRadius:16,marginTop:18},bt:{color:'#fff',textAlign:'center',fontWeight:'900',fontSize:16},link:{padding:18},linkText:{textAlign:'center',color:'#4B197D',fontWeight:'800'}});
