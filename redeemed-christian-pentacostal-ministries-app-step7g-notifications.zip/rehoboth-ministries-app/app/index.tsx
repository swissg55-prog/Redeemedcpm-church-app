import { Link } from 'expo-router';
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const purple = '#4B197D';
const light = '#F7F4FA';

export default function Home() {
  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        <View style={s.header}>
          <Image source={require('../assets/church-logo.jpg')} style={s.logo} />
          <View style={{flex:1}}>
            <Text style={s.name}>REDEEMED CHRISTIAN</Text>
            <Text style={s.name}>PENTACOSTAL MINISTRIES</Text>
            <Text style={s.tag}>Touching Lives for Christ</Text>
          </View>
        </View>

        <View style={s.hero}>
          <Text style={s.heroKicker}>WELCOME TO OUR CHURCH APP</Text>
          <Text style={s.heroTitle}>Jesus Christ</Text>
          <Text style={s.heroVerse}>“The same yesterday and today and forever.”</Text>
          <Text style={s.reference}>Hebrews 13:8</Text>
        </View>

        <Text style={s.section}>Upcoming Services</Text>
        <Service icon="📖" day="WED" title="Wednesday Bible Study" time="18:00 - 20:00" />
        <Service icon="🙏" day="FRI" title="Friday Prayer Meeting" time="18:00 - 20:00" />
        <Service icon="⛪" day="SUN" title="Sunday Church Service" time="09:00 - 12:00" />

        <Text style={s.section}>Stay Connected</Text>
        <View style={s.grid}>
          <Tile href="/events" icon="📅" label="Events" />
          <Tile href="/prayer" icon="🙏" label="Prayer Requests" />
          <Tile href="/live" icon="▶" label="Live Stream" />
          <Tile href="/contact" icon="☎" label="Contact Us" />
          <Tile href="/auth" icon="👤" label="Member Account" /><Tile href="/profile" icon="🙍" label="My Profile" /><Tile href="/admin" icon="🔐" label="Church Admin" />
        </View>

        <View style={s.quote}>
          <Text style={s.quoteText}>A House of Prayer, A Place of Power, A Family in Christ.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Service({icon, day, title, time}: any) {
  return <View style={s.card}>
    <View style={s.day}><Text style={s.dayText}>{day}</Text></View>
    <Text style={s.serviceIcon}>{icon}</Text>
    <View style={{flex:1}}><Text style={s.cardTitle}>{title}</Text><Text style={s.time}>{time}</Text></View>
  </View>;
}
function Tile({href, icon, label}: any) {
  return <Link href={href} asChild><Pressable style={s.tile}><Text style={s.tileIcon}>{icon}</Text><Text style={s.tileText}>{label}</Text></Pressable></Link>;
}

const s = StyleSheet.create({
  safe:{flex:1,backgroundColor:light}, container:{padding:18,paddingBottom:35},
  header:{backgroundColor:'#160B22',borderRadius:22,padding:16,flexDirection:'row',alignItems:'center'},
  logo:{width:68,height:68,borderRadius:18,marginRight:13}, name:{color:'#fff',fontSize:15,fontWeight:'900',letterSpacing:.3}, tag:{color:'#D7A9E7',fontSize:13,fontStyle:'italic',marginTop:7},
  hero:{marginTop:16,borderRadius:24,padding:26,backgroundColor:purple,alignItems:'center'}, heroKicker:{color:'#EADCF3',fontSize:11,fontWeight:'800',letterSpacing:1.5}, heroTitle:{color:'#fff',fontSize:38,fontWeight:'900',fontStyle:'italic',marginTop:18}, heroVerse:{color:'#fff',fontSize:14,textAlign:'center',marginTop:8}, reference:{color:'#E6C66A',fontWeight:'800',marginTop:5},
  section:{fontSize:21,fontWeight:'900',color:'#24132F',marginTop:24,marginBottom:11},
  card:{backgroundColor:'#fff',borderRadius:18,padding:14,marginBottom:10,flexDirection:'row',alignItems:'center',gap:12,elevation:2}, day:{width:48,height:48,borderRadius:14,backgroundColor:'#EFE4F7',alignItems:'center',justifyContent:'center'}, dayText:{color:purple,fontWeight:'900',fontSize:12}, serviceIcon:{fontSize:24}, cardTitle:{fontSize:16,fontWeight:'800',color:'#25152E'}, time:{color:'#756A7A',marginTop:4,fontWeight:'600'},
  grid:{flexDirection:'row',flexWrap:'wrap',gap:12}, tile:{width:'47.8%',backgroundColor:'#fff',borderRadius:18,padding:18,alignItems:'center',borderWidth:1,borderColor:'#E8DFED'}, tileIcon:{fontSize:26}, tileText:{marginTop:8,fontWeight:'800',color:'#3B1C52'},
  quote:{marginTop:22,backgroundColor:'#24102F',borderRadius:20,padding:20}, quoteText:{color:'#fff',textAlign:'center',fontSize:16,fontStyle:'italic',fontWeight:'700',lineHeight:23}
});
