import { Stack } from 'expo-router';
import { useEffect } from 'react';
import {
  registerDeviceWithServer,
  scheduleWeeklyReminders,
} from '../lib/notifications';
import { supabase } from '../lib/supabase';

export default function RootLayout() {
  useEffect(() => {
    // Register immediately for guests and members.
    registerDeviceWithServer().catch(console.warn);
    scheduleWeeklyReminders().catch(console.warn);

    // Re-register after login so the push token is associated with
    // the authenticated member in public.devices.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        registerDeviceWithServer().catch(console.warn);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="auth" />
      <Stack.Screen name="profile" />
      <Stack.Screen name="prayer" />
      <Stack.Screen name="events" />
      <Stack.Screen name="live" />
      <Stack.Screen name="contact" />
      <Stack.Screen name="admin" />
    </Stack>
  );
}
