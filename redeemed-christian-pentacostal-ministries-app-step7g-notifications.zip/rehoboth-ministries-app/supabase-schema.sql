-- Redeemed Christian Pentacostal Ministries: Step 5 church management backend
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  expo_push_token text unique not null,
  platform text not null,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.prayer_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request text not null,
  status text not null default 'new' check (status in ('new','prayed','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  day_label text not null,
  start_time text not null,
  end_time text,
  icon text default '📅',
  event_date date,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.church_settings (
  id integer primary key default 1 check (id = 1),
  church_name text not null default 'Redeemed Christian Pentacostal Ministries',
  tagline text default 'Touching Lives for Christ',
  phone text,
  whatsapp text,
  email text,
  address text,
  livestream_url text,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.devices enable row level security;
alter table public.prayer_requests enable row level security;
alter table public.events enable row level security;
alter table public.announcements enable row level security;
alter table public.church_settings enable row level security;

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Remove/recreate policies so this script can be safely re-run.
do $$ declare r record; begin
  for r in select policyname, tablename from pg_policies where schemaname='public' and tablename in ('profiles','devices','prayer_requests','events','announcements','church_settings') loop
    execute format('drop policy if exists %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

create policy "Users can read their own profile" on public.profiles for select using (auth.uid() = id);
create policy "Admins can read all profiles" on public.profiles for select using (public.is_admin());
create policy "Admins can update profiles" on public.profiles for update using (public.is_admin()) with check (public.is_admin());

create policy "Users can register a device" on public.devices for insert with check (auth.uid() = user_id or user_id is null);
create policy "Users can update their own device" on public.devices for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Admins can manage devices" on public.devices for all using (public.is_admin()) with check (public.is_admin());

create policy "Members can submit prayer requests" on public.prayer_requests for insert with check (auth.uid() = user_id);
create policy "Members can read their own prayer requests" on public.prayer_requests for select using (auth.uid() = user_id);
create policy "Admins can read prayer requests" on public.prayer_requests for select using (public.is_admin());
create policy "Admins can update prayer requests" on public.prayer_requests for update using (public.is_admin()) with check (public.is_admin());

create policy "Everyone can read active events" on public.events for select using (active = true or public.is_admin());
create policy "Admins can manage events" on public.events for all using (public.is_admin()) with check (public.is_admin());

create policy "Everyone can read announcements" on public.announcements for select using (true);
create policy "Admins can create announcements" on public.announcements for insert with check (public.is_admin());
create policy "Admins can manage announcements" on public.announcements for delete using (public.is_admin());

create policy "Everyone can read church settings" on public.church_settings for select using (true);
create policy "Admins can manage church settings" on public.church_settings for all using (public.is_admin()) with check (public.is_admin());

insert into public.church_settings (id) values (1) on conflict (id) do nothing;
insert into public.events (title, description, day_label, start_time, end_time, icon)
select 'Wednesday Bible Study', 'Grow in God’s Word', 'WEDNESDAY', '18:00', '20:00', '📖'
where not exists (select 1 from public.events where title='Wednesday Bible Study');
insert into public.events (title, description, day_label, start_time, end_time, icon)
select 'Friday Prayer Meeting', 'Together in Prayer', 'FRIDAY', '18:00', '20:00', '🙏'
where not exists (select 1 from public.events where title='Friday Prayer Meeting');
insert into public.events (title, description, day_label, start_time, end_time, icon)
select 'Sunday Church Service', 'Worship & Fellowship', 'SUNDAY', '09:00', '12:00', '⛪'
where not exists (select 1 from public.events where title='Sunday Church Service');

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name') on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
