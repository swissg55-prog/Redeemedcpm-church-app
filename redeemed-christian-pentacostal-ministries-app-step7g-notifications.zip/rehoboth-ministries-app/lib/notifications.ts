import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { supabase, supabaseConfigured } from './supabase';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function registerForPushNotificationsAsync() {
  if (!Device.isDevice) return null;

  const existing = await Notifications.getPermissionsAsync();
  let status = existing.status;
  if (status !== 'granted') {
    status = (await Notifications.requestPermissionsAsync()).status;
  }
  if (status !== 'granted') return null;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('church', {
      name: 'Church reminders',
      importance: Notifications.AndroidImportance.HIGH,
      sound: 'default',
    });
  }

  const projectId =
    Constants.expoConfig?.extra?.eas?.projectId ||
    process.env.EXPO_PUBLIC_EAS_PROJECT_ID;

  const token = (
    await Notifications.getExpoPushTokenAsync(
      projectId ? { projectId } : undefined
    )
  ).data;

  return token;
}

export async function registerDeviceWithServer() {
  if (!supabaseConfigured) return { token: null, synced: false };

  const token = await registerForPushNotificationsAsync();
  if (!token) return { token: null, synced: false };

  const { data: { user } } = await supabase.auth.getUser();

  // Upsert by the unique Expo push token. This also lets a device
  // registered before login become associated with the member after login.
  const payload = {
    expo_push_token: token,
    platform: Platform.OS,
    user_id: user?.id ?? null,
    active: true,
    updated_at: new Date().toISOString(),
  };

  const { error } = await supabase
    .from('devices')
    .upsert(payload, { onConflict: 'expo_push_token' });

  if (error) throw error;

  return { token, synced: true };
}

export async function scheduleWeeklyReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();

  const reminders = [
    {
      weekday: 4,
      hour: 17,
      minute: 0,
      title: '📖 Bible Study Reminder',
      body: 'Bible Study starts today. Join us as we study God’s Word together.',
    },
    {
      weekday: 6,
      hour: 17,
      minute: 0,
      title: '🙏 Friday Prayer Reminder',
      body: 'It’s prayer night! Join us for our Friday prayer meeting.',
    },
    {
      weekday: 1,
      hour: 8,
      minute: 0,
      title: '⛪ Sunday Service Reminder',
      body: 'You’re invited to worship with us today. We look forward to seeing you!',
    },
  ];

  for (const reminder of reminders) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: reminder.title,
        body: reminder.body,
        sound: 'default',
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
        weekday: reminder.weekday,
        hour: reminder.hour,
        minute: reminder.minute,
      },
    });
  }
}
