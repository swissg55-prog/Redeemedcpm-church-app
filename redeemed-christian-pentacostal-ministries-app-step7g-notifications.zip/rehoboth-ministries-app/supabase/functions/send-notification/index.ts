import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'POST required' }, 405);

  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (!token) return json({ error: 'Unauthorized' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      return json({ error: 'Server configuration is incomplete' }, 500);
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const {
      data: { user },
      error: userError,
    } = await userClient.auth.getUser();

    if (userError || !user) return json({ error: 'Unauthorized' }, 401);

    const admin = createClient(supabaseUrl, serviceRoleKey);

    const { data: profile, error: profileError } = await admin
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profileError || profile?.role !== 'admin') {
      return json({ error: 'Admin access required' }, 403);
    }

    const payload = await req.json();
    const title = String(payload?.title ?? '').trim();
    const body = String(payload?.body ?? '').trim();
    const extraData =
      payload?.data && typeof payload.data === 'object' ? payload.data : {};

    if (!title || !body) {
      return json({ error: 'title and body are required' }, 400);
    }

    const { data: devices, error: deviceError } = await admin
      .from('devices')
      .select('expo_push_token')
      .eq('active', true);

    if (deviceError) return json({ error: deviceError.message }, 500);

    const messages = (devices ?? []).map((device) => ({
      to: device.expo_push_token,
      sound: 'default',
      title,
      body,
      data: { church: 'rcpm', ...extraData },
    }));

    let sent = 0;

    for (let i = 0; i < messages.length; i += 100) {
      const chunk = messages.slice(i, i + 100);

      const response = await fetch(
        'https://exp.host/--/api/v2/push/send',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(chunk),
        }
      );

      if (!response.ok) {
        const detail = await response.text();
        console.error('Expo push request failed:', detail);
        continue;
      }

      sent += chunk.length;
    }

    return json({
      sent,
      targeted: messages.length,
    });
  } catch (error) {
    console.error(error);
    return json({ error: String(error) }, 500);
  }
});
