# STEP 7G — Push Notifications

This step connects the church administrator dashboard to Expo push notifications through a Supabase Edge Function.

## What is included

- Member/device push-token registration.
- Automatic re-registration after a member signs in.
- Android notification channel.
- Weekly local reminders.
- Admin-only `send-notification` Edge Function.
- Admin dashboard already calls the Edge Function from the Announcements tab.

## Supabase setup

1. Open the Supabase project:
   `https://gkasndgxvbuenxgwhuyt.supabase.co`
2. Open **Edge Functions** and deploy the function:
   `supabase/functions/send-notification/index.ts`
3. Add/verify the server secret:
   `SUPABASE_SERVICE_ROLE_KEY`
   Use the **service-role key from Supabase Settings > API**. Never put this key in `.env` used by the mobile app.
4. Confirm the function has access to the normal Supabase environment values:
   `SUPABASE_URL`
   `SUPABASE_ANON_KEY`
5. Make sure `supabase-schema.sql` has been executed so the `devices`, `profiles`, and `announcements` tables exist.

## Important EAS requirement

`.env` still contains:

`EXPO_PUBLIC_EAS_PROJECT_ID=YOUR_EAS_PROJECT_ID`

That value must be replaced with the Expo/EAS project ID before production push notifications can be built reliably.

## Test flow

1. Install/run the app on a physical Android phone.
2. Allow notification permission.
3. Sign in as the church administrator.
4. Open **Church Admin → Announcements**.
5. Enter a title and message.
6. Tap **Save & Send Push Notification**.
7. The announcement is saved in Supabase and the Edge Function sends it to active registered devices.

## Security

The mobile app only contains the Supabase public/anon key.
The service-role key belongs only in the Edge Function server secret configuration.
