-- Run this AFTER creating the administrator account in Supabase Auth.
-- This uses the administrator email to find the Auth user and promote the matching
-- profile to admin. Never put the user's password in this SQL file.
update public.profiles
set role = 'admin'
where id = (
  select id from auth.users
  where lower(email) = lower('redeemedpentacostalministries@gmail.com')
  limit 1
);

-- Verify:
select p.id, u.email, p.full_name, p.role
from public.profiles p
join auth.users u on u.id = p.id
where lower(u.email) = lower('redeemedpentacostalministries@gmail.com');
