# Step 7F — Supabase connection

The project is configured for the Supabase project URL and public anon key.

1. In Supabase SQL Editor, run `supabase-schema.sql`.
2. In Supabase Authentication, create the administrator user with the church administrator email/password.
3. Run `admin-promote.sql` to set that user's profile role to `admin`.
4. Keep the Supabase service-role key out of the mobile app. It belongs only in the Edge Function/server secret configuration.
5. Before an Android/iOS production build, replace `YOUR_EAS_PROJECT_ID` in `.env` with the Expo/EAS project ID after the EAS project is created/configured.
